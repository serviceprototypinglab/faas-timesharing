import socket
import time
import threading

def lambda_handler(event, context):
    time.sleep(5)
    s = socket.gethostbyname(socket.gethostname())
    s += "." + str(threading.get_ident())
    return s
